package com.ieseljust.pmdm.comptador


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import android.widget.TextView
import com.ieseljust.pmdm.comptador.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    var comptador=0
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        val view=binding.root
        setContentView(R.layout.activity_main)

        // Referencia al TextView
        val textViewContador=findViewById<TextView>(R.id.textViewComptador)

        // Comprobar que la instancia guardada no es nula i aixina poder guardar el resultat
        if(savedInstanceState!=null){
            comptador=savedInstanceState.getInt("comptador")
        }
        // Inicialitzem el TextView amb el comptador a 0
        textViewContador.setText(comptador.toString())

        // Referencia al botón de sumar
        val btAdd=findViewById<Button>(R.id.btAdd)

        // Referencia al boton de restar
        val btResta=findViewById<Button>(R.id.btResta)

        // Referencia al boton de resetear

        val btReset=findViewById<Button>(R.id.btReset)
        // Asociaciamos una expresióin lambda como
        // respuesta (callback) al evento Clic sobre
        // el botón
        btAdd.setOnClickListener {
            comptador++
            textViewContador.setText(comptador.toString())

            savedInstanceState?.putInt("comptador",comptador)
        }
        btResta.setOnClickListener{
            comptador--
            textViewContador.setText(comptador.toString())
            savedInstanceState?.putInt("comptador",comptador)
        }
        btReset.setOnClickListener{
            comptador=0
            textViewContador.setText(comptador.toString())
            savedInstanceState?.putInt("comptador",comptador)
        }

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("comptador",comptador)
    }

}